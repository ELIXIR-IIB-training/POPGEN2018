## PLOTS COINCIDENCE MATRIX FROM FINESTRUCTURE OUTPUT:

################################
## INPUT:

out.file="BrahuiYorubaSimulationAllVersusAllChrom22FSCoincidencePlot.pdf"

in.fileCOINCIDENCEA="BrahuiYorubaSimulationAllVersusAllChrom22.finestructureCOINCIDENCE.out"
in.fileCOINCIDENCEB="BrahuiYorubaSimulationAllVersusAllChrom22.finestructureCOINCIDENCEII.out"

filename.finestructure="BrahuiYorubaSimulationAllVersusAllChrom22.finestructureTREE.out"

################################
## PROGRAM:

library(ape)

                   ## (I) READ IN TREE:
FS.tree=read.tree(filename.finestructure,skip=20)
FS.tip=FS.tree$tip

                   ## (II) GET COINCIDENCE MATRICES:
coincidence.readA=read.table(in.fileCOINCIDENCEA,header=TRUE,sep=',')
coincidence.matA=matrix(as.matrix(coincidence.readA[,2:dim(coincidence.readA)[2]]),ncol=dim(coincidence.readA)[2]-1)
recipient.namesA=as.character(coincidence.readA$coincidence)
recipient.names2A=names(coincidence.readA)[2:dim(coincidence.readA)[2]]
coincidence.matA=coincidence.matA[match(FS.tip,recipient.namesA),match(FS.tip,recipient.names2A)]
coincidence.readB=read.table(in.fileCOINCIDENCEB,header=TRUE,sep=',')
coincidence.matB=matrix(as.matrix(coincidence.readB[,2:dim(coincidence.readB)[2]]),ncol=dim(coincidence.readB)[2]-1)
recipient.namesB=as.character(coincidence.readB$coincidence)
recipient.names2B=names(coincidence.readB)[2:dim(coincidence.readB)[2]]
coincidence.matB=coincidence.matB[match(FS.tip,recipient.namesB),match(FS.tip,recipient.names2B)]

coincidence.mat=coincidence.matA
for (i in 1:(dim(coincidence.matB)[1]-1))
    coincidence.mat[i,((i+1):(dim(coincidence.matB)[2]))]=coincidence.matB[i,((i+1):(dim(coincidence.matB)[2]))]

                   ## (III) PLOT COINCIDENCE MATRIX:
pdf(out.file)
layout(matrix(c(1,2),nrow=1), width=c(8, 1))

                                   ## colors (from Dan Lawson):
colby<-0.05
some.colors2<-c("white",rgb(1,seq(1,colby,-colby),colby),rgb(1,colby,seq(colby,1,colby)),rgb(seq(1,colby,-colby),colby,1.0),"black")
colscale<-c(min(coincidence.mat),max(coincidence.mat))
colindex<-t(matrix(seq(colscale[1],colscale[2],length.out=100),ncol=1,nrow=100))
                                   ## plot (from Dan Lawson):
par(mar=c(1,1,0.5,0.5))
image(1:dim(coincidence.mat)[1],1:dim(coincidence.mat)[1],t(coincidence.mat),xaxt="n",yaxt="n",xlab="",ylab="",col=some.colors2,zlim=colscale)
                                   ## legend (from Dan Lawson):
par(las=2,mgp=c(0,1,0),mar=c(0,0,0,0.5),fig=c(0.90,0.95,0.05,0.95),new=T)
image(0,1:100,colindex,xaxt="n",yaxt="n",xlab="",ylab="",col=some.colors2,zlim=colscale)
box(lty=1)
axis(4,at=seq(1,100,length.out=10),labels=signif(min(colindex)+(max(colindex)-min(colindex))*seq(0,1,length.out=10),3),las=2,tick=FALSE,cex.axis=0.8,line=-0.5)

dev.off()

q(save='no')
