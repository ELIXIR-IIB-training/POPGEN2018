## Usage: Rscript <options> calcC.R basefilename <ending>
## basefilename is required
## <ending> is optional and by default is "out"
## Quotes are not needed
## Options:
##      -s n            Skips the first n lines (default: 0)
##      -d <delim>      Set the deliminator (default: space " ")
## Example: Rscript calcC.R Test would read three files:
##      Test.regionsum.out              # the sum of n_{ijk} over k
##      Test.regionsumsquared.out       # the sum of n_{ijk}^2 over k
##      Test.regioncount.out            # the number of regions k
ca<-commandArgs(TRUE)
## If using inline, you can create the command args like so:
#ca<-c("-s", "0","-f", "AllContsEurope.force", "-d",",","AllPopsAllChrom.ExpectationRhoChunkSizeSingleRhoJackKnife","nmat")
#ca<-c("-s", "0","-d",",","AllPopsAllChrom.ExpectationRhoChunkSizeSingleRhoJackKnife","nmat")
if(length(ca)<1) print("Must provide a file name!")
skip<-0
delim<-" "
force=""
while(length(grep("-",ca[1])>=1)){
if(ca[1]=="-s") {
  skip<-ca[2]
  ca<-ca[-(1:2)]
}
if(ca[1]=="-d") {
  delim<-ca[2]
  ca<-ca[-(1:2)]
}
if(ca[1]=="-f") {
  force<-ca[2]
  ca<-ca[-(1:2)]
}
}
if(length(ca)<1) print("Must provide a file name!")
basefilename<-ca[1]
if(length(ca)<2) {
  ending<-"out";
}else{
  ending<-ca[2]
}

forceconts<-vector("character")
forceinds<-list()
liston<-1
if(force!="") {
  tmp<-readLines(force)
  tmp2<-strsplit(tmp,"(",fixed=TRUE)
  for(i in 1:length(tmp2)){
    if(length(grep("#",tmp2[[i]][1]))==0){
      forceconts<-c(forceconts,tmp2[[i]][1])
      forceinds[liston]<-strsplit(strsplit(tmp2[[i]][2],")",fixed=TRUE)[[1]],",")
      liston<-liston+1
    }
  }
}

mergeCont<-function(mat,contname,indnums){
  names1<-dimnames(mat)[[1]]
  mat2<-mat[-indnums,-indnums]
  n1<-dim(mat2)[1]
  mat2<-cbind(rbind(mat2,0),0)
  dimnames(mat2)[[1]][n1+1]<- dimnames(mat2)[[2]][n1+1]<-contname
  names2<-dimnames(mat2)[[1]]
  for(i in 1:n1){
    j<-which(names1==names2[i])
    mat2[i,n1+1]<-sum(mat[j,indnums])
    mat2[n1+1,i]<-sum(mat[indnums,j])
  }
  mat2[n1+1,n1+1]<-sum(mat[indnums,indnums])
  mat2
}

mergeContVec<-function(vec,contname,indnums){
  vec2<-c(vec[-indnums],0)
  names(vec2)[length(vec2)]<-contname
  vec2[length(vec2)]<-sum(vec[indnums])
  vec2
}

nsum<-as.matrix(read.table(paste(basefilename,".regionchunkcounts.",ending,sep=""),skip = skip,row.names=1,header=TRUE,sep=delim))
nsqsum<-as.matrix(read.table(paste(basefilename,".regionsquaredchunkcounts.",ending,sep=""),skip = skip,row.names=1,header=TRUE,sep=delim))
nregcount<-as.matrix(read.table(paste(basefilename,".regionchunkcounts.",ending,sep=""),skip = skip,row.names=1,header=TRUE,sep=delim))[,1]
nsum=nsum[,-1]
nsqsum=nsqsum[,-1]
nsumsq<-nsum^2

nsumOrig<-nsum
nsqsumOrig<-nsqsum
nregcountOrig<-nregcount
nsumsqOrig<-nsumsq

if(length(forceconts)>0){
for(i in 1:length(forceconts)){
  dn<-dimnames(nsum)[[1]]
  mergenums<-sapply(forceinds[[i]],function(x){which(x==dn)})
  nsum<-mergeCont(nsum,forceconts[i],mergenums)
  nsqsum<-mergeCont(nsqsum,forceconts[i],mergenums)
  nsumsq<-mergeCont(nsumsq,forceconts[i],mergenums)
  nregcount<-mergeContVec(nregcount,forceconts[i],mergenums)
}
}


############

calcB<-function(mvec,Nmat){
rem<-which(mvec<=1)
if(length(rem)>0){
  mvec<-mvec[-rem]
  Nmat<-Nmat[-rem,-rem]
}
Pest<-Nmat/ rowSums(Nmat)
(rowSums(Nmat)*Pest*(1-Pest)/mvec)
}

calcA<-function(mvec,Nmatsumsq,Nmatsqsum){
rem<-which(mvec<=1)
if(length(rem)>0){
  mvec<-mvec[-rem]
  #Nmatsum<-Nmatsum[-rem,-rem]
  Nmatsqsum<-Nmatsqsum[-rem,-rem]
  Nmatsumsq<-Nmatsumsq[-rem,-rem]
}
(( Nmatsqsum/ (mvec-1) - (Nmatsumsq/mvec/(mvec-1))))
}

Amat<-calcA(nregcount,nsumsq,nsqsum)
Bmat<-calcB(nregcount,nsum)
tdat<-2*(Amat+t(Amat))/(Bmat+t(Bmat))
tdat2<-mean(na.omit(as.vector(tdat)))
cat(paste(tdat2,"\n",sep=""))

